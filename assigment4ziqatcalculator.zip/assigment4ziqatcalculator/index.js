#! /usr/bin/env node

import inquirer from "inquirer";

// Function to calculate Zakat
async function calculateZakat() {
    // Prompt the user for input
    const response = await inquirer.prompt([
        {
            type: 'number',
            name: 'totalWealthPKR',
            message: 'Enter your total wealth in PKR:',
            validate: function (value) {
                if (isNaN(value) || value <= 0) {
                    return 'Please enter a valid positive number.';
                }
                return true;
            }
        },
        {
            type: 'number',
            name: 'goldGrams',
            message: 'Enter the weight of gold you possess (in grams):',
            validate: function (value) {
                if (isNaN(value) || value <= 0) {
                    return 'Please enter a valid positive number.';
                }
                return true;
            }
        },
        {
            type: 'number',
            name: 'silverGrams',
            message: 'Enter the weight of silver you possess (in grams):',
            validate: function (value) {
                if (isNaN(value) || value <= 0) {
                    return 'Please enter a valid positive number.';
                }
                return true;
            }
        }
    ]);

    // Calculate Zakat for gold (2.5% of gold value in PKR)
    const zakatGoldPKR = (response.goldGrams * 24 * 80) * 0.025; // Assuming gold rate is 80 PKR per gram

    // Calculate Zakat for silver (2.5% of silver value in PKR)
    const zakatSilverPKR = (response.silverGrams * 0.8) * 0.025; // Assuming silver rate is 0.8 PKR per gram

    // Calculate Zakat for wealth (2.5% of total wealth in PKR)
    const zakatWealthPKR = response.totalWealthPKR * 0.025;

    // Calculate total Zakat
    const totalZakatPKR = zakatGoldPKR + zakatSilverPKR + zakatWealthPKR;

    // Display the result
    console.log(`Your Zakat amount for gold is: PKR ${zakatGoldPKR.toFixed(2)}`);
    console.log(`Your Zakat amount for silver is: PKR ${zakatSilverPKR.toFixed(2)}`);
    console.log(`Your Zakat amount for wealth is: PKR ${zakatWealthPKR.toFixed(2)}`);
    console.log(`Total Zakat amount is: PKR ${totalZakatPKR.toFixed(2)}`);
}

// Call the function to start the calculation
calculateZakat();
